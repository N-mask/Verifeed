import React, { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { store, type User } from "@/lib/store";

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => string | null;
  register: (user: Omit<User, "id">) => string | null;
  logout: () => void;
  refreshUser: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => store.getCurrentUser());

  const refreshUser = useCallback(() => {
    const cur = store.getCurrentUser();
    if (cur) {
      const fresh = store.findUserById(cur.id);
      if (fresh) {
        store.setCurrentUser(fresh);
        setUser(fresh);
      }
    }
  }, []);

  const login = useCallback((email: string, password: string): string | null => {
    const found = store.findUser(email, password);
    if (!found) return "Invalid email or password";
    store.setCurrentUser(found);
    setUser(found);
    return null;
  }, []);

  const register = useCallback((userData: Omit<User, "id">): string | null => {
    const existing = store.getUsers().find((u) => u.email === userData.email);
    if (existing) return "Email already registered";
    if (userData.password.length < 6) return "Password must be at least 6 characters";
    const newUser: User = { ...userData, id: crypto.randomUUID() };
    store.addUser(newUser);
    store.setCurrentUser(newUser);
    setUser(newUser);
    return null;
  }, []);

  const logout = useCallback(() => {
    store.setCurrentUser(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
