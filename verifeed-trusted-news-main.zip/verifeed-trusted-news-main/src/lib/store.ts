export type Role = "user" | "publisher" | "expert";

export interface User {
  id: string;
  email: string;
  username: string;
  password: string;
  role: Role;
  expertise?: string;
  acceptedTerms?: boolean;
  banned?: boolean;
}

export interface NewsPost {
  id: string;
  title: string;
  category: string;
  preview: string;
  content: string;
  publisherId: string;
  publisherName: string;
  createdAt: string;
}

export interface Rating {
  newsId: string;
  expertId: string;
  stars: number;
}

const USERS_KEY = "verifeed_users";
const NEWS_KEY = "verifeed_news";
const RATINGS_KEY = "verifeed_ratings";
const CURRENT_USER_KEY = "verifeed_current_user";

function get<T>(key: string, fallback: T): T {
  try {
    const d = localStorage.getItem(key);
    return d ? JSON.parse(d) : fallback;
  } catch {
    return fallback;
  }
}
function set(key: string, val: unknown) {
  localStorage.setItem(key, JSON.stringify(val));
}

export const store = {
  getUsers: (): User[] => get(USERS_KEY, []),
  saveUsers: (u: User[]) => set(USERS_KEY, u),
  addUser: (u: User) => {
    const users = store.getUsers();
    users.push(u);
    store.saveUsers(users);
  },
  findUser: (email: string, password: string) =>
    store.getUsers().find((u) => u.email === email && u.password === password),
  findUserById: (id: string) => store.getUsers().find((u) => u.id === id),

  getNews: (): NewsPost[] => get(NEWS_KEY, []),
  saveNews: (n: NewsPost[]) => set(NEWS_KEY, n),
  addNews: (n: NewsPost) => {
    const news = store.getNews();
    news.unshift(n);
    store.saveNews(news);
  },

  getRatings: (): Rating[] => get(RATINGS_KEY, []),
  saveRatings: (r: Rating[]) => set(RATINGS_KEY, r),
  addRating: (r: Rating) => {
    const ratings = store.getRatings();
    const idx = ratings.findIndex(
      (x) => x.newsId === r.newsId && x.expertId === r.expertId
    );
    if (idx >= 0) ratings[idx] = r;
    else ratings.push(r);
    store.saveRatings(ratings);
    store.checkBan(r.newsId);
  },

  getAvgRatingForNews: (newsId: string): number | null => {
    const ratings = store.getRatings().filter((r) => r.newsId === newsId);
    if (ratings.length === 0) return null;
    return ratings.reduce((s, r) => s + r.stars, 0) / ratings.length;
  },

  getPublisherAvgRating: (publisherId: string): number | null => {
    const news = store.getNews().filter((n) => n.publisherId === publisherId);
    if (news.length === 0) return null;
    const ratings = store
      .getRatings()
      .filter((r) => news.some((n) => n.id === r.newsId));
    if (ratings.length === 0) return null;
    return ratings.reduce((s, r) => s + r.stars, 0) / ratings.length;
  },

  checkBan: (newsId: string) => {
    const news = store.getNews().find((n) => n.id === newsId);
    if (!news) return;
    const avg = store.getPublisherAvgRating(news.publisherId);
    if (avg !== null && avg < 1.5) {
      const users = store.getUsers();
      const idx = users.findIndex((u) => u.id === news.publisherId);
      if (idx >= 0) {
        users[idx].banned = true;
        store.saveUsers(users);
      }
    }
  },

  getCurrentUser: (): User | null => get(CURRENT_USER_KEY, null),
  setCurrentUser: (u: User | null) => set(CURRENT_USER_KEY, u),
};
