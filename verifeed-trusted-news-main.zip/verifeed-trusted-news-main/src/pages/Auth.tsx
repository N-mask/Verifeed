import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import type { Role } from "@/lib/store";
import { Newspaper, ArrowRight } from "lucide-react";
import heroBanner from "@/assets/hero-banner.jpg";

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState<Role>("user");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [expertise, setExpertise] = useState("");
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [error, setError] = useState("");
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (isLogin) {
      const err = login(email, password);
      if (err) { setError(err); return; }
    } else {
      if (role === "publisher" && !acceptedTerms) { setError("You must accept the Terms & Conditions"); return; }
      if (!/^[a-zA-Z0-9]{6,}$/.test(password)) { setError("Password must be at least 6 alphanumeric characters"); return; }
      const err = register({ email, username: role === "expert" ? username : username, password, role, expertise: role !== "user" ? expertise : undefined, acceptedTerms: role === "publisher" ? acceptedTerms : undefined });
      if (err) { setError(err); return; }
    }
    navigate("/feed");
  };

  const roles: { value: Role; label: string }[] = [
    { value: "user", label: "Reader" },
    { value: "publisher", label: "Publisher" },
    { value: "expert", label: "Expert" },
  ];

  return (
    <div className="min-h-screen flex">
      {/* Left: Hero */}
      <div className="hidden lg:flex lg:w-1/2 relative items-end p-12"
        style={{ backgroundImage: `url(${heroBanner})`, backgroundSize: "cover", backgroundPosition: "center" }}
      >
        <div className="absolute inset-0 bg-primary/70" />
        <div className="relative z-10 text-primary-foreground">
          <div className="flex items-center gap-2 mb-6">
            <Newspaper className="h-8 w-8" />
            <span className="font-display text-3xl font-bold tracking-tight">VeriFeed</span>
          </div>
          <h1 className="font-display text-4xl font-bold leading-tight mb-4">
            Trusted News,<br />Expert Verified.
          </h1>
          <p className="text-lg opacity-80 max-w-md">
            A community-driven platform where experts verify the news you read. Credibility you can trust.
          </p>
        </div>
      </div>

      {/* Right: Form */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md fade-in">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <Newspaper className="h-6 w-6 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">VeriFeed</span>
          </div>

          <h2 className="font-display text-2xl font-bold mb-1">
            {isLogin ? "Welcome back" : "Create your account"}
          </h2>
          <p className="text-muted-foreground text-sm mb-8">
            {isLogin ? "Sign in to continue reading verified news." : "Join the trusted news community."}
          </p>

          {error && (
            <div className="mb-4 p-3 rounded-md bg-destructive/10 text-destructive text-sm font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="text-sm font-medium mb-2 block">I am a</label>
                <div className="grid grid-cols-3 gap-2">
                  {roles.map((r) => (
                    <button
                      key={r.value}
                      type="button"
                      onClick={() => setRole(r.value)}
                      className={`py-2 px-3 rounded-md text-sm font-medium border transition-all ${
                        role === r.value
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-border hover:border-primary/40"
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {!isLogin && role === "expert" && (
              <div>
                <label className="text-sm font-medium mb-1 block">Full Name</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Dr. Jane Smith"
                />
              </div>
            )}

            <div>
              <label className="text-sm font-medium mb-1 block">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="you@example.com"
              />
            </div>

            {!isLogin && role !== "expert" && (
              <div>
                <label className="text-sm font-medium mb-1 block">Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="johndoe"
                />
              </div>
            )}

            <div>
              <label className="text-sm font-medium mb-1 block">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="••••••"
              />
            </div>

            {!isLogin && (role === "publisher" || role === "expert") && (
              <div>
                <label className="text-sm font-medium mb-1 block">Expertise Field</label>
                <input
                  type="text"
                  required
                  value={expertise}
                  onChange={(e) => setExpertise(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="e.g. Political Science, AI, Health"
                />
              </div>
            )}

            {!isLogin && role === "publisher" && (
              <label className="flex items-start gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptedTerms}
                  onChange={(e) => setAcceptedTerms(e.target.checked)}
                  className="mt-0.5 rounded border-input"
                />
                <span className="text-muted-foreground">
                  I accept the <span className="text-primary font-medium underline">Terms & Conditions</span> and agree to abide by VeriFeed's editorial standards.
                </span>
              </label>
            )}

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-2.5 px-4 rounded-md font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              {isLogin ? "Sign In" : "Create Account"}
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button
              onClick={() => { setIsLogin(!isLogin); setError(""); }}
              className="text-primary font-semibold hover:underline"
            >
              {isLogin ? "Register" : "Sign In"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
