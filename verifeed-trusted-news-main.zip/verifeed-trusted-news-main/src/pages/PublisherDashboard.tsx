import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { store } from "@/lib/store";
import Navbar from "@/components/Navbar";
import StarRating from "@/components/StarRating";
import { AlertTriangle, PlusCircle, BarChart3, FileText } from "lucide-react";

const CATEGORIES = ["World", "Technology", "Health", "Science", "Business"];

export default function PublisherDashboard() {
  const { user, refreshUser } = useAuth();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [preview, setPreview] = useState("");
  const [content, setContent] = useState("");
  const [success, setSuccess] = useState("");

  if (!user || user.role !== "publisher") return null;

  refreshUser();
  const isBanned = user.banned === true;
  const avgRating = store.getPublisherAvgRating(user.id);
  const myNews = store.getNews().filter((n) => n.publisherId === user.id);

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (isBanned) return;
    store.addNews({
      id: crypto.randomUUID(),
      title,
      category,
      preview,
      content,
      publisherId: user.id,
      publisherName: user.username,
      createdAt: new Date().toISOString(),
    });
    setTitle("");
    setPreview("");
    setContent("");
    setSuccess("Article published successfully!");
    setTimeout(() => setSuccess(""), 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="font-display text-3xl font-bold mb-8">Publisher Dashboard</h1>

        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-3 mb-8">
          <div className="p-5 rounded-lg border border-border bg-card">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
              <BarChart3 className="h-4 w-4" /> Credibility Score
            </div>
            <div className="flex items-center gap-3">
              <StarRating rating={avgRating} size="md" />
              {isBanned && <span className="badge-banned"><AlertTriangle className="h-3 w-3" /> BANNED</span>}
            </div>
          </div>
          <div className="p-5 rounded-lg border border-border bg-card">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
              <FileText className="h-4 w-4" /> Articles Published
            </div>
            <p className="text-2xl font-bold">{myNews.length}</p>
          </div>
          <div className="p-5 rounded-lg border border-border bg-card">
            <div className="text-muted-foreground text-sm mb-2">Status</div>
            <p className={`text-lg font-bold ${isBanned ? "text-destructive" : "text-verified"}`}>
              {isBanned ? "Banned" : "Active"}
            </p>
          </div>
        </div>

        {isBanned && (
          <div className="mb-8 p-4 rounded-lg bg-destructive/10 border border-destructive/20 flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-destructive">Your account has been banned</p>
              <p className="text-sm text-destructive/80">Your average credibility rating has fallen below 1.5 stars. You can no longer publish new articles.</p>
            </div>
          </div>
        )}

        {/* Post Form */}
        {!isBanned && (
          <div className="p-6 rounded-lg border border-border bg-card mb-8 fade-in">
            <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
              <PlusCircle className="h-5 w-5" /> Publish New Article
            </h2>
            {success && (
              <div className="mb-4 p-3 rounded-md bg-verified/10 text-verified text-sm font-medium">{success}</div>
            )}
            <form onSubmit={handlePost} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Title</label>
                <input
                  required value={title} onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Your headline..."
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Category</label>
                <select
                  value={category} onChange={(e) => setCategory(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Preview (short summary)</label>
                <input
                  required value={preview} onChange={(e) => setPreview(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Brief description..."
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Full Content</label>
                <textarea
                  required value={content} onChange={(e) => setContent(e.target.value)}
                  rows={8}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-y"
                  placeholder="Write your article..."
                />
              </div>
              <button
                type="submit"
                className="bg-primary text-primary-foreground py-2.5 px-6 rounded-md font-semibold text-sm hover:opacity-90 transition-opacity"
              >
                Publish Article
              </button>
            </form>
          </div>
        )}

        {/* My Articles */}
        <h2 className="font-display text-xl font-bold mb-4">Your Articles</h2>
        <div className="space-y-3">
          {myNews.map((n) => {
            const r = store.getAvgRatingForNews(n.id);
            return (
              <div key={n.id} className="p-4 rounded-lg border border-border bg-card flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{n.title}</p>
                  <p className="text-xs text-muted-foreground">{n.category}</p>
                </div>
                <StarRating rating={r} />
              </div>
            );
          })}
          {myNews.length === 0 && <p className="text-muted-foreground text-sm">No articles yet.</p>}
        </div>
      </main>
    </div>
  );
}
