import { useParams, useNavigate } from "react-router-dom";
import { store } from "@/lib/store";
import { useAuth } from "@/contexts/AuthContext";
import StarRating from "@/components/StarRating";
import Navbar from "@/components/Navbar";
import { ArrowLeft, CheckCircle, AlertTriangle, User } from "lucide-react";
import { useState } from "react";

export default function NewsDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const post = store.getNews().find((n) => n.id === id);
  const [, setRefresh] = useState(0);

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="text-xl font-display">Article not found</p>
          <button onClick={() => navigate("/feed")} className="mt-4 text-primary font-semibold hover:underline">
            Back to feed
          </button>
        </div>
      </div>
    );
  }

  const avgRating = store.getAvgRatingForNews(post.id);
  const isVerified = avgRating !== null && avgRating >= 3;
  const publisher = store.findUserById(post.publisherId);
  const publisherAvg = store.getPublisherAvgRating(post.publisherId);

  const existingRating = user?.role === "expert"
    ? store.getRatings().find((r) => r.newsId === post.id && r.expertId === user.id)
    : null;

  const handleRate = (stars: number) => {
    if (!user || user.role !== "expert") return;
    store.addRating({ newsId: post.id, expertId: user.id, stars });
    setRefresh((r) => r + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <button
          onClick={() => navigate("/feed")}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to feed
        </button>

        <article className="fade-in">
          <div className="flex items-center gap-2 mb-4">
            <span className="badge-category">{post.category}</span>
            {isVerified && (
              <span className="badge-verified"><CheckCircle className="h-3 w-3" /> Expert Verified</span>
            )}
            {publisher?.banned && (
              <span className="badge-banned"><AlertTriangle className="h-3 w-3" /> Publisher Banned</span>
            )}
          </div>

          <h1 className="font-display text-3xl sm:text-4xl font-bold leading-tight mb-4">
            {post.title}
          </h1>

          <div className="flex items-center gap-4 pb-6 mb-6 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                <User className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-sm">{post.publisherName}</p>
                <p className="text-xs text-muted-foreground">
                  {publisherAvg !== null ? `Publisher Rating: ${publisherAvg.toFixed(1)}★` : "Not yet rated"}
                </p>
              </div>
            </div>
            <div className="ml-auto">
              <StarRating rating={avgRating} size="md" />
            </div>
          </div>

          <div className="prose prose-lg max-w-none">
            {post.content.split("\n\n").map((p, i) => (
              <p key={i} className="text-foreground/90 leading-relaxed mb-4">{p}</p>
            ))}
          </div>

          {/* Expert Rating */}
          {user?.role === "expert" && (
            <div className="mt-8 p-6 rounded-lg border border-border bg-card">
              <h3 className="font-display text-lg font-bold mb-2">Expert Verification</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Rate the accuracy and credibility of this article.
              </p>
              <StarRating
                rating={existingRating?.stars ?? null}
                interactive
                onRate={handleRate}
                size="md"
              />
              {existingRating && (
                <p className="text-xs text-muted-foreground mt-2">
                  You rated this article {existingRating.stars} stars. Click to update.
                </p>
              )}
            </div>
          )}
        </article>
      </main>
    </div>
  );
}
