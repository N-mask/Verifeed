import { store } from "@/lib/store";
import { Zap } from "lucide-react";

export default function NewsTicker() {
  const news = store.getNews().slice(0, 6);
  const items = news.map((n) => n.title);
  const doubled = [...items, ...items];

  return (
    <div className="ticker-wrap">
      <div className="container mx-auto flex items-center">
        <span className="flex items-center gap-1.5 px-4 font-semibold text-sm shrink-0 border-r border-primary-foreground/20 mr-4 pr-4">
          <Zap className="h-4 w-4" />
          BREAKING
        </span>
        <div className="overflow-hidden flex-1">
          <div className="ticker-content">
            {doubled.map((t, i) => (
              <span key={i} className="mx-8 text-sm font-medium">
                {t} <span className="mx-4 opacity-40">•</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
