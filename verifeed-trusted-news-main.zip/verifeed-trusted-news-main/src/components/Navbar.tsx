import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import { Newspaper, LogOut, LayoutDashboard } from "lucide-react";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  if (!user) return null;

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-card/80 backdrop-blur-md">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <button onClick={() => navigate("/feed")} className="flex items-center gap-2 group">
          <Newspaper className="h-6 w-6 text-primary transition-transform group-hover:rotate-[-6deg]" />
          <span className="font-display text-xl font-bold text-primary tracking-tight">VeriFeed</span>
        </button>

        <div className="flex items-center gap-4">
          {user.role === "publisher" && (
            <button
              onClick={() => navigate("/dashboard")}
              className={`flex items-center gap-1.5 text-sm font-medium transition-colors hover:text-primary ${location.pathname === "/dashboard" ? "text-primary" : "text-muted-foreground"}`}
            >
              <LayoutDashboard className="h-4 w-4" />
              Dashboard
            </button>
          )}
          <div className="flex items-center gap-2 text-sm">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold text-xs">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="hidden sm:block">
              <p className="font-medium leading-tight">{user.username}</p>
              <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
            </div>
          </div>
          <button
            onClick={() => { logout(); navigate("/"); }}
            className="text-muted-foreground hover:text-destructive transition-colors p-1"
            title="Logout"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </nav>
  );
}
