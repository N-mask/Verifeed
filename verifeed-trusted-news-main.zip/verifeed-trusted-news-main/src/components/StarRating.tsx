import { Star } from "lucide-react";

interface StarRatingProps {
  rating: number | null;
  interactive?: boolean;
  onRate?: (stars: number) => void;
  size?: "sm" | "md";
}

export default function StarRating({ rating, interactive = false, onRate, size = "sm" }: StarRatingProps) {
  const s = size === "sm" ? "h-4 w-4" : "h-5 w-5";

  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={!interactive}
          onClick={() => interactive && onRate?.(star)}
          className={`transition-transform ${interactive ? "hover:scale-125 cursor-pointer" : "cursor-default"}`}
        >
          <Star
            className={`${s} transition-colors ${
              rating !== null && star <= Math.round(rating)
                ? "fill-star text-star"
                : "fill-star-empty text-star-empty"
            }`}
          />
        </button>
      ))}
      {rating !== null && (
        <span className="ml-1.5 text-xs font-medium text-muted-foreground">
          {rating.toFixed(1)}
        </span>
      )}
    </div>
  );
}
