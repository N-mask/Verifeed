import { useNavigate } from "react-router-dom";
import { store, type NewsPost } from "@/lib/store";
import StarRating from "./StarRating";
import { CheckCircle, Clock } from "lucide-react";

export default function NewsCard({ post, index }: { post: NewsPost; index: number }) {
  const navigate = useNavigate();
  const avgRating = store.getAvgRatingForNews(post.id);
  const isVerified = avgRating !== null && avgRating >= 3;
  const timeAgo = getTimeAgo(post.createdAt);

  return (
    <article
      onClick={() => navigate(`/news/${post.id}`)}
      className={`news-card fade-in`}
      style={{ animationDelay: `${index * 0.08}s` }}
    >
      <div className="flex items-center gap-2 mb-3">
        <span className="badge-category">{post.category}</span>
        {isVerified && (
          <span className="badge-verified">
            <CheckCircle className="h-3 w-3" /> Verified
          </span>
        )}
      </div>
      <h3 className="font-display text-lg font-bold leading-snug mb-2 line-clamp-2">
        {post.title}
      </h3>
      <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-2">
        {post.preview}
      </p>
      <div className="flex items-center justify-between border-t border-border pt-3">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="font-semibold text-foreground">{post.publisherName}</span>
          <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{timeAgo}</span>
        </div>
        <StarRating rating={avgRating} />
      </div>
    </article>
  );
}

function getTimeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}
